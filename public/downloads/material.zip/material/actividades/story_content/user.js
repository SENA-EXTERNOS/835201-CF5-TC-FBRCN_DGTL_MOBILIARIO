function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6UJfn91kwr0":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

